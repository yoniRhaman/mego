import random
lvl_1 = '''
  +---+
  |   |
      |
      |
      |
      |
========='''
lvl_2 = '''
  +---+
  |   |
  O   |
      |
      |
      |
========='''
lvl_3 = '''
  +---+
  |   |
  O   |
 /|\  |
      |
      |
========='''
lvl_4 = '''
  +---+
  |   |
  O   |
 /|\  |
 / \  |
      |
=========
YOU LOSER!!!'''

#רשימה של השמות למשחק
words = [
"Peach",
"Grape",
"Kiwi",
"Mango",
"Lemon",
"Fig",
"Date",
"Lychee",
"Guava",
"Papaya"]

# בחר מילה אקראית מהרשימה
chosen_word = random.choice(words)
word_length = len(chosen_word)

# כמה צעדים למשחק יש לו
attempts = 4
correct_letters = []
underscores = ['_'] * word_length
hangman_level = 0

# הלולאה תתקיים כל עוד יש מספר צעדים
while attempts > 0:
    print(" ".join(underscores))#עושה רווח בין כל מקו
    guess = input("Guess a letter: ").lower()#משנה לאותיות קטנות

    if len(guess) != 1 or not guess.isalpha():#בודק אם זה לא תו או כמות
        print("Please enter a single letter.")
        continue

    if guess in correct_letters:#בודק עם יש כבר את האות הזאת
        print("You've already guessed that letter.")
        continue

    if guess in chosen_word:#עם האות קיימת במילה
        for i in range(word_length):#מריץ בכל אינדקס בכמות אותיות במילה
            if chosen_word[i] == guess:#מציאת האינדקס שרשום
                underscores[i] = guess#תכניס במקום הקו
        correct_letters.append(guess)#תכניס את האות
    else:
        print("Incorrect guess. You have", attempts - 1, "attempts left.")#בחירה שגיאת של אות
        # הדפסה של השלבים של האיש תלוי
        attempts -= 1
        hangman_level += 1
        if hangman_level == 1:
            print(lvl_1)
        elif hangman_level == 2:
            print(lvl_2)
        elif hangman_level == 3:
            print(lvl_3)
        elif hangman_level == 4:
            print(lvl_4)
            break

    if "_" not in underscores:#בדיקה שאין מקו והצלחת
        print("Congratulations! You've guessed the word:", chosen_word)
        break

# If the player used all their attempts without guessing the word
if "_" in underscores:
    print("You've run out of attempts. The word was:", chosen_word)#גילוי המילה אחרי שהפסיד


