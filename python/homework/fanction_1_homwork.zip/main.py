def multiplication_num(num1,num2,num3):
    print(num1*num2*num3)
    
def full_name(first_name,last_name):
    print(first_name,last_name)
    
def max_number(num1, num2, num3):
    if num1 > num2 or num1 > num3:
        print(f"The biggest number is: {num1}")
    elif num2 > num3 or num2 > num1:
        print(f"The biggest number is: {num2}")
    else:
        print(f"The biggest number is: {num3}")
        
def longest_name():
    student1 = input(str("Enter the name of the first student: "))
    student2 = input(str("Enter the name of the second student: "))
    student3 = input(str("Enter the name of the third student: "))

    if len(student1) >= len(student2) and len(student1) >= len(student3):
        print(f"The student with the longest name is: {student1}")
    elif len(student2) >= len(student1) and len(student2) >= len(student3):
        print(f"The student with the longest name is: {student2}")
    else:
        print(f"The student with the longest name is: {student3}")
        
def even_odd(num):
    if num % 2 == 0:
        print(f"The number {num} is even")
    else:
        print(f"The number {num} is odd")
        
     
import math

def circle_area(radius):
    return math.pi * (radius ** 2)

radius = float(input("Enter the radius of the circle: "))
area = circle_area(radius)
print(f"The area of the circle is: {area:.2f}")



