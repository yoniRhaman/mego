print('''
         \||/
                |  @___oo
      /\  /\   / (__,,,,|
     ) /^\) ^\/ _)
     )   /^\/   _)
     )   _ /  / _)
 /\  )/\/ ||  | )_)
<  >      |(,,) )__)
 ||      /    \)___)\
 | \____(      )___) )___
  \______(_______;;; __;;;
''')

print("Welcome to the Maze and Dragons game!")

# Initialize player's position in the maze
x, y = 0, 0

while True:
    # Print player's current position
    print(f"You are at position ({x}, {y})")

    # Check for obstacles and provide options to navigate
    if x == 2 and y == 1:
        print("You have encountered a dragon!")
        action = input("Do you want to fight (f) or run (r)? ")

        if action == 'f':
            print("You bravely fought the dragon and defeated it!")
            x += 1
        elif action == 'r':
            print("You ran away from the dragon!")
            x -= 1
        else:
            print("Invalid choice! Try again.")

    elif x == 3 and y == 3:
        print("You found a locked door!")
        action = input("Do you want to try and open it (o) or go back (b)? ")

        if action == 'o':
            print("Congratulations! You successfully unlocked the door and escaped!")
            break
        elif action == 'b':
            print("You went back to avoid the locked door.")
            y -= 1
        else:
            print("Invalid choice! Try again.")

    else:
        direction = input("Enter a direction (up 'w', down 's', left 'a', right 'd', or quit 'q'): ")

        if direction == 'w':
            y += 1
        elif direction == 's':
            y -= 1
        elif direction == 'a':
            x -= 1
        elif direction == 'd':
            x += 1
        elif direction == 'q':
            print("You decided to quit the game.")
            break
        else:
            print("Invalid direction! Try again.")
