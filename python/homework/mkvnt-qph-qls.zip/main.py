
from coffee_maker import CoffeeMaker
from menu import Menu  
from money_machine import MoneyMachine


my_coffee_maker = CoffeeMaker()
my_menu = Menu()
my_money_machine = MoneyMachine()


while True:
   
    customer_choice = input("Choose a coffee (latte/espresso/cappuccino) or type 'off' to turn off: ")

    if customer_choice == "off":
        break

    if customer_choice not in ("latte", "espresso", "cappuccino"):
        print("invalid choice")
        continue

    selected_drink = my_menu.find_drink(customer_choice)


    if my_coffee_maker.is_resource_sufficient(selected_drink) and my_money_machine.make_payment(selected_drink.cost):
      
        my_coffee_maker.make_coffee(selected_drink)

