import grafik

money_inside = 0
latte_price = 2.5
cappuccino_price = 3
espresso_price = 1.5

coffee_machine_tank = {
    "milk": 10000,
    "water": 10000,
    "coffee": 1000,
    "price": 1000
}

def choose_cofe():
    choose_kind = input("Please enter the code for your desired coffee (e/c/l for espresso, cappuccino, and latte): ")
    if choose_kind == "e":
        price_cofe = espresso_price
    elif choose_kind == "c":
        price_cofe = cappuccino_price
    elif choose_kind == "l":
        price_cofe = latte_price
    elif choose_kind == "owner":
        owner_machine()
        return None, 0
    else:
        print("Please choose a correct code")
        return None, 0
    return choose_kind, price_cofe

def down_cofe(choose_kind):
    # Add logic to decrease resources based on the chosen coffee type
    pass

def insert_money(price_cofe):
    total_price = 0
    while total_price < price_cofe:
        choose_coin = input("Please enter the code for the coin you want to insert (p/n/d/q): ")
        if choose_coin == "p":
            total_price += 0.01
        elif choose_coin == "n":
            total_price += 0.05
        elif choose_coin == "d":
            total_price += 0.1
        elif choose_coin == "q":
            total_price += 0.25
        else:
            print("Please insert a valid coin.")
        print(f"The total price you have inserted is: {total_price}")
    coffee_machine_tank["price"] += total_price
    print("Thank you! Enjoy your coffee.")

def report_machine():
    print("Coffee Machine Report:")
    print(coffee_machine_tank)

def owner_machine():
    report_machine()
    add_or_not = input("Do you want to add something? (y/n): ")
    if add_or_not == "n":
        print("Ok, have a good day!")
        main_machine()
    elif add_or_not == "y":
        coffee_machine_tank["milk"] += int(input("Please add milk: "))
        coffee_machine_tank["water"] += int(input("Please add water: "))
        coffee_machine_tank["coffee"] += int(input("Please add coffee: "))
        take_money = input("Do you want to take money? (y/n): ")
        if take_money == "n":
            print("Ok, have a good day!")
            main_machine()
        elif take_money == "y":
            print(f"The machine has ${coffee_machine_tank['price']}")
            coffee_machine_tank['price'] -= int(input("How much do you want to take? "))
            print("Ok, have a good day!")

def main_machine():
    print("Welcome to the coffee machine!")
    choose_kind, price_cofe = choose_cofe()
    if choose_kind:
        down_cofe(choose_kind)
        insert_money(price_cofe)
        
        
print(grafik.welcome)
main_machine()
