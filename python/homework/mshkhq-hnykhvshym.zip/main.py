import grafik
import random

def guessing(number_random, attempts):
    for attempts in range(attempts, 0, -1):
        guessing_number = int(input("Plz enter a number for the guessing game: "))
        if guessing_number > number_random:
            print("Too high. Guess again.")
        elif guessing_number < number_random:
            print("Too low. Guess again.")
        else:
            print("You guessed the number!")
            return True
    print(f"You've run out of attempts. The correct number was: {number_random}")
    return False

number_random = random.randint(1, 100)
print(grafik.welcome)

choose_lvl = input("Plz choose hard or easy (h/e): ")
if choose_lvl == "h":
    attempts = 5
elif choose_lvl == "e":
    attempts = 10
else:
    print("Plz choose again...")

if not guessing(number_random,attempts):
    print("Game over. Try again!")
