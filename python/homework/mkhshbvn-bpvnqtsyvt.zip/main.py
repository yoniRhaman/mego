calculator = ''' _____________________
|  _________________  |
| |   Welcome to    | |
| |   Calculator!   | |
|  ___ ___ ___   ___  |
| | 7 | 8 | 9 | | + | |
| |___|___|___| |___| |
| | 4 | 5 | 6 | | - | |
| |___|___|___| |___| |
| | 1 | 2 | 3 | | x | |
| |___|___|___| |___| |
| | . | 0 | = | | / | |
| |___|___|___| |___| |
|_____________________|'''
print(calculator)
print("Hello, and welcome to the calculator!")

def add(num1, num2):
    return num1 + num2

def subtract(num1, num2):
    return num1 - num2

def multiply(num1, num2):
    return num1 * num2

def divide(num1, num2):
    if num2 == 0:
        return "Cannot divide by zero"
    return num1 / num2

a = float(input("Please enter the first number: "))
b = float(input("Please enter the second number: "))

to_check = input("Choose the operator for the calculator (+, -, *, /): ")
if to_check == "+":
    result = add(a, b)
    
elif to_check == "-":
    result = subtract(a, b)
   
elif to_check == "*":
    result = multiply(a, b)
    
elif to_check == "/":
    result = divide(a, b)
     
else:
    print("Please enter the correct operator")

print(f"The result is: {result}")
