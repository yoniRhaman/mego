import os


def caesar_code():
    word = input("Choose a word: ").casefold()
    code = int(input("Choose how many letters you want to insert the word?: "))
    new_word = []
    for i in word:
        caesar = ord(i) + code
        if caesar > 122:
            caesar -= 26
        caesar = chr(caesar)
        new_word.append(caesar)
    print(''.join(new_word))



def decryption():
    lost_word = input("Choose a encrypted word: ").casefold()
    lost_code = int(input(
        "Choose a few letters to repeat the word: "))
    real_word = []
    for i in lost_word:
        caesar = ord(i) + lost_code
        if caesar < 97:
            caesar += 26
        caesar = chr(caesar)
        real_word.append(caesar)
    print(''.join(real_word))



back = 0
print(f"Welcome to the cypher program: ")
while back != 1:
    choice = input("Choose what you want to do: Encrypt or Decrypt? (e/d) ").casefold()
    if choice == "e":
        caesar_code()
    else:
        decryption()

    continued = input("Would you like to continue or exit? c/q ").casefold()
    if continued == "q":
        exit()
    os.system('cls' if os.name == 'nt' else 'clear')