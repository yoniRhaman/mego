boy_name =input("Enter your name man let's see if you are in love ").lower()
girl_name =input("Enter your name girl let's see if you are in love  ").lower()


boy_and_girl=(boy_name + girl_name)
count_names=len(boy_and_girl)
total=0
total+= boy_and_girl.count("t")
total+= boy_and_girl.count("r")
total+= boy_and_girl.count("u")
total+= boy_and_girl.count("e")
total+= boy_and_girl.count("l")
total+= boy_and_girl.count("o")
total+= boy_and_girl.count("v")
total+= boy_and_girl.count("e")



total_percent=(total/count_names)*100
if total_percent > 60:
    print("This is love for sure ")
elif total_percent < 60 and total_percent > 40:
    print("Check well If she is right for you")
else:
   print("Unfortunately you are not suitable")