

def Wall_calculation(length, width):
    sum = length * width / 5
    print(f"The price is {sum:.2f}") 


length = float(input("Please give me the length of the wall: "))
width = float(input("Please give me the width of the wall: "))

Wall_calculation(length, width)
