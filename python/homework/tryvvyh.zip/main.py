class Question:
    def __init__(self, text, answer):
        self.text = text
        self.answer = answer

class QuizGame:
    def __init__(self):
        self.question_data = [
            Question("A slug's blood is green.", "True"),
            Question("The loudest animal is the African Elephant.", "False"),
            Question("Approximately one quarter of human bones are in the feet.", "True"),
            Question("The total surface area of a human lung is the size of a football pitch.", "True"),
            Question("In West Virginia, USA, if you accidentally hit an animal with your car, you are free to take it home to eat.", "True"),
            Question("In London, UK, if you happen to die in the House of Parliament, you are entitled to a state funeral.", "False"),
            Question("It is illegal to pee in the Ocean in Portugal.", "True"),
            Question("You can lead a cow downstairs but not upstairs.", "False"),
            Question("Google was originally called 'Backrub'.", "True"),
            Question("Buzz Aldrin's mother's maiden name was 'Moon'.", "True"),
            Question("No piece of square dry paper can be folded in half more than 7 times.", "False"),
            Question("A few ounces of chocolate can kill a small dog.", "True")
        ]
        self.choose_play = 0

    def welcome(self):
        print("Welcome to the QuizGame!!")

    def choose_to_play(self):
        global choose_play
        choose_play = input("Please enter 'y' to play: ")
        if choose_play == "y":
            print("Okay, let's get started!")
        else:
            print("See you later.")

    def ask_question(self, question):
        user_answer = input(question.text + " (True/False): ")
        return user_answer.lower() == question.answer.lower()

    def play_game(self):
        score = 0
        for question in self.question_data:
            if self.ask_question(question):
                print("Correct!")
                score += 1
            else:
                print("Incorrect. The correct answer is", question.answer)

        print(f"You scored {score}/{len(self.question_data)}.")

# Example of how to use the QuizGame class
quiz_game = QuizGame()
quiz_game.welcome()
quiz_game.choose_to_play()
if choose_play == "y":
    quiz_game.play_game()