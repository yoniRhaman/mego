import random
print("hello to cube game")

print("user turn")
player = random.randint(1,6)
print("cpu turn")
cpu = random.randint(1,6)

if cpu > player:
    print("The cpu won")
elif cpu < player:
    print("The user won")
else:
    print("Its is even")
