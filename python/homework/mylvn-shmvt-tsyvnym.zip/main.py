student_scores = {
    "Avi": 100,
    "liam": 90,
    "James": 60,
    "Henry": 75,
    "Alexander": 80
}
students_grades={}
for grade  in student_scores:
    if student_scores[grade] < 70:
        students_grades[grade] = "Failed test again "
    elif 70 <= student_scores[grade] < 80:
        students_grades[grade] = "you can do more from this"
    elif 80 <= student_scores[grade]< 90:
        students_grades[grade] = "Very good grade"
    else:
        students_grades[grade]="Amazing"

print(students_grades)