
def encrypt(text, offset):
    encrypted_text = ""
    for char in text:
        if 'a' <= char <= 'z':
            encrypted_char = chr(((ord(char) - ord('a') + offset) % 26) + ord('a'))
        elif 'A' <= char <= 'Z':
            encrypted_char = chr(((ord(char) - ord('A') + offset) % 26) + ord('A'))
        else:
            encrypted_char = char  
        encrypted_text += encrypted_char
    return encrypted_text


def decrypt(text, offset):
    return encrypt(text, -offset)  

while True:
    print("Welcome to the Caesar Cipher program")
    choice = input("Choose what you would like to do:\nEncrypt (press 1)\nDecrypt (press 2)\nQuit (press Q)\n---> ")
    
    if choice == "1":
        text = input("Enter the text to encrypt >>> ")
        offset = int(input("Enter the offset >>> "))
        encrypted_text = encrypt(text, offset)
        print("Encrypted sentence:", encrypted_text)
    elif choice == "2":
        text = input("Enter the encrypted sentence >>> ")
        offset = int(input("Enter the offset >>> "))
        decrypted_text = decrypt(text, offset)
        print("Decrypted sentence:", decrypted_text)
    elif choice.upper() == "Q":
        print("Goodbye!")
        break
    else:
        print("Invalid choice. Please enter 1 to Encrypt, 2 to Decrypt, or Q to Quit.")
