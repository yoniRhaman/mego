Large_pizze = 25
Medium_pizze = 20
Small_pizze = 15
olives_Large = 6
olives_Medium = 4
olives_Small = 2
olives_and_mushrooms_Large_or_Small = 5
olives_and_mushrooms_Small = 2
cheese = 3
total = 0

print("Welcome to Eyal's burnt pizza!")
size_pizze = (input("What size pizza are you want? (Large. or Medium. or Small?)" ))
extra_olives = (input("Are you interested in the addition of olives?(yes or no?)"))
extra_olives_and_mushrooms = (input("Are you interested in the addition of olives and mushrooms?(yes or no?)"))

if size_pizze.casefold()[0] == "L":
    total = Large_pizze
    if extra_olives.casefold()[0] == "y":
        total = Large_pizze + olives_Large
    elif extra_olives_and_mushrooms.casefold()[0] == "y":
        total = Large_pizze + olives_and_mushrooms_Large_or_Small
elif size_pizze.casefold()[0] == "M":
    total = Medium_pizze
    if extra_olives.casefold()[0] == "y":
        total = Medium_pizze + olives_Medium
    elif extra_olives_and_mushrooms.casefold()[0] == "y":
        total = Medium_pizze + olives_and_mushrooms_Large_or_Small
elif size_pizze.casefold()[0] == "S":
    total = Small_pizze
    if extra_olives.casefold()[0] == "y":
        total = Small_pizze + olives_Small
    elif extra_olives_and_mushrooms.casefold()[0] == "y":
        total = Small_pizze + olives_and_mushrooms_Small
print(f"you need to pay {total} plz ")