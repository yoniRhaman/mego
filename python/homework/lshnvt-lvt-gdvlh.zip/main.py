
def uppercase(input_string):
    return input_string.title()
string = input("Please enter a name to switch to uppercase: ")


result = uppercase(string)

print(result)
