package lesson1;

/**
 * Created by erankatsav on 28/01/2018.
 */
public class Garage {

    final int GARAGE_SIZE  = 25;

    private String name;
    private String address;
    private Car[] cars;

    private int numOfCars;

    public Garage(String name, String address) {

        this.name = name;
        this.address = address;
        cars = new Car[GARAGE_SIZE];
        numOfCars = 0;
    }

    public String getName() {
        return this.name;
    }

    public String getAddress() {
        return this.address;
    }

    public void addCar(Car car) {
        if(numOfCars < GARAGE_SIZE) {

            cars[numOfCars] = car;//new Car(car);
            numOfCars++;
        }
    }

    public void print() {
        System.out.println("This is a garage it's name is " + this.name + ", and it is located in " + this.address);
        if(numOfCars>0) {
            for(int i=0;i<numOfCars;i++) {
                cars[i].print();
            }
        }
    }

}
