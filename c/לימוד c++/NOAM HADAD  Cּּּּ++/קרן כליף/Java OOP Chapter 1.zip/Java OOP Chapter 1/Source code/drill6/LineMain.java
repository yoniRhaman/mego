package lesson1.drill6;

/**
 * Created by erankatsav on 29/01/2018.
 */
public class LineMain {

    public static void main(String[] args) {

        Point a = new Point(-6,5);
        Point b = new Point(-2,9);
        Point c = new Point(1,6);
        Point d = new Point(-3,2);

        Line ab = new Line(a,b);
        Line bc = new Line(b,c);
        Line cd = new Line(c,d);
        Line da = new Line(d,a);

        System.out.println("AB distance " + ab.distance());
        System.out.println("CD distance " + cd.distance());

        System.out.println();

        System.out.println("BC distance " + bc.distance());
        System.out.println("DA distance " + da.distance());

        System.out.println("AB slope * BC slope is: " + ab.slope() * bc.slope());
        System.out.println("BC slope * CD slope is: " + bc.slope() * cd.slope());
        System.out.println("CD slope * DA slope is: " + cd.slope() * da.slope());
        System.out.println("DA slope * AB slope is: " + da.slope() * ab.slope());
    }
}
