package lesson1;

/**
 * Created by erankatsav on 28/01/2018.
 */
public class Car {

    private int price;
    private String color;

    public Car(int price, String color) {
        this.price = price;
        this.color = color;
    }

    public Car(Car other) {
        this(other.price,other.color);
    }

    public int getPrice() {
        return this.price;
    }

    public String getColor() {
        return this.color;
    }

    public void print() {
        System.out.println("This is a Car it cost " + this.price + " and it's color is " + this.color);
    }
}
