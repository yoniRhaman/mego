package lesson1.drill1;

/**
 * Created by erankatsav on 28/01/2018.
 */
public class PersonMain {

    public static void main(String[] args) {

        Person person1 = new Person("Moshe Cohen",12345667,40);

        Person person2 = new Person("Yael Levi",67676765);

        System.out.println("person1:");
        person1.print();

        System.out.println("person2");
        person2.print();

        person1.addYear();
        person2.addYear();

        System.out.println("The bigger is:");
        if(person1.isBigger(person2))
            person1.print();
        else person2.print();
    }
}
