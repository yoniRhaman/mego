package lesson1.drill1;

/**
 * Created by erankatsav on 28/01/2018.
 */
public class Person {

    private String name;
    private long id;
    private int age;

    public Person(String name, long id, int age) {
        this.name = name;
        this.id = id;
        this.age = age;
    }

    public Person(String name, long id) {
        this(name,id,30);
    }

    public Person() {
        this("John Doe",0,0);
    }

    public String getName() {
        return  this.name;
    }

    public int getAge() {
        return this.age;
    }

    public long getId() {
        return  this.id;
    }

    public void addYear() {
        this.age++;
    }

    public boolean isBigger(Person other) {
        return (this.age > other.age);
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setAge(int age) {
        if(age>=0)
            this.age = age;
    }

    public void print() {
        System.out.println("This is a person his name is " + this.name + " his id is " + this.id
        +" and his age is " + this.age);
    }
}
