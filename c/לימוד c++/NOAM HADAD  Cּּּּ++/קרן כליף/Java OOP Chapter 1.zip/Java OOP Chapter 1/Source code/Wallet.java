package lesson1;

/**
 * Created by erankatsav on 28/01/2018.
 */
public class Wallet {

    private int capacity;
    private double currentMoney;
    private String color;

    private static int numOfWallets = 0; //counts the number of wallets manufactured

    public Wallet(int capacity, double currentMoney, String color) {

        this.capacity = capacity;
        this.currentMoney = currentMoney;
        this.color = color;

        numOfWallets++;

        System.out.println("Finished 3-args ctor");
    }

    public Wallet(int capacity) {
        this(capacity,0,"Red");
       /* this.capacity = capacity;
        this.currentMoney = 0;
        this.color = "Red";*/
        System.out.println("Finished 1-arg ctor");

    }

    public Wallet() {
        this(1000);
        System.out.println("Finished  no - args ctor");
    }

    public Wallet(Wallet wallet) {
        this(wallet.capacity, wallet.currentMoney, wallet.color);
        /*this.capacity = wallet.capacity;
        this.currentMoney = wallet.currentMoney;
        this.color = wallet.color;*/
    }

    public static int getNumOfWallets() {
        return numOfWallets;
    }

    public int getCapacity() {
        return this.capacity;
    }

    public double getCurrentMoney() {
        return this.currentMoney;
    }

    public String getColor() {
        return this.color;
    }

    public void setCurrentMoney(double currentMoney) {

        if(currentMoney>0 && currentMoney<this.capacity) {
            this.currentMoney = currentMoney;
        }
    }

    public boolean isEmpty() {
        return (this.currentMoney==0);
    }

    public void empty() {
        this.currentMoney = 0;
    }

    public void fillMoney(double amount) {
        if(this.capacity<this.currentMoney + amount) { //if there is not space for all the amount
            this.currentMoney = this.capacity;
        }
        else {
            this.currentMoney += amount;
        }
    }

    public void transferMoney(Wallet other) {

        double freeSpace  = other.capacity - other.currentMoney;
        if(this.capacity < freeSpace) { //he has place for all of our money
            other.fillMoney(this.capacity);
            empty(); //same as this.empty();
        }
        else {
            other.fillMoney(freeSpace);
            this.currentMoney -= freeSpace;
        }
    }

    public static Wallet combineWallets(Wallet w1,Wallet w2) {
        return new Wallet(w1.capacity + w2.capacity,w1.currentMoney + w2.currentMoney,"White");
    }

    public void print() {
        System.out.println("This is a Wallet, it's capacity is " + this.capacity + ", it currently holding "
         + this.currentMoney + ", and it's color is " + this.color);
    }

}
