package lesson1;

/**
 * Created by erankatsav on 28/01/2018.
 */
public class WalletMain {

    public static void main(String[] args) {

        Wallet w1 = new Wallet(1000,67.5,"Black");

        Wallet w2 = new Wallet(2000);

        System.out.println("w1:");
        w1.print();

        System.out.println("w2:");
        w2.print();

        w1.empty();
        System.out.println("w1 after emptying:");
        w1.print();

        w1.fillMoney(1500);
        System.out.println("w1 after filling money");
        w1.print();

        w1.transferMoney(w2);
        System.out.println("w1 after trasfering money to w2:");
        w1.print();

        System.out.println("w2 after receiving money from w1:");
        w2.print();

        Wallet w3 = w2; //be carefull... reference copying
        System.out.println("w3:");
        w3.print();

        w2.empty();

        System.out.println("w3 after emptying w2:");
        w3.print();

        Wallet w4  = new Wallet(w2);
        System.out.println("w4:");
        w2.fillMoney(4000);

        System.out.println("w2 after filling:");
        w2.print();

        System.out.println("w4 after filling w2:");
        w4.print();

        System.out.println("Total number of wallets in the world: " + Wallet.getNumOfWallets());

        Wallet w5 = Wallet.combineWallets(w2,w4);
        System.out.println("w5:");
        w5.print();

    }
}
