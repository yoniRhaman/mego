package lesson1.drill2;

/**
 * Created by erankatsav on 28/01/2018.
 */
public class Worker {

    private String name;
    private int years;
    private int age;
    private int salary;

    public Worker(String name, int years,int age,int salary) {
        this.name = name;
        this.years = years;
        this.age = age;
        this.salary = salary;
    }

    public String getName() {
        return this.name;
    }

    public  int getYears() {
        return this.years;
    }

    public int getAge() {
        return this.age;
    }

    public int getSalary() {
        return this.salary;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setAge(int age) {
        if(age>0) this.age =age;
    }

    public void setYears(int years) {
        if(years >0 && years<this.age) {
            this.years = years;
        }
    }

    public void setSalary(int salary) {
        if(this.salary > 0)
            this.salary = salary;
    }

    public void addBonus(int amount) {
        this.salary += amount;
    }

    public void print() {
        System.out.println("This is a Worker, his name is " + this.name + " his salary is " + this.salary
        + " he has " + this.years + " years of experience " + " and he is " + +this.age + " years old");
    }
}
