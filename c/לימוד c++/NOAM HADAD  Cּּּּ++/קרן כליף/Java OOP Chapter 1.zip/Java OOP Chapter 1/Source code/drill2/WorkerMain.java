package lesson1.drill2;

/**
 * Created by erankatsav on 28/01/2018.
 */
public class WorkerMain {

    public static void main(String[] args) {


        Worker[] workers = new Worker[3];

        workers[0] = new Worker("Mohse",10,40,6800);
        workers[1] = new Worker("Ravit",15,45,7500);
        workers[2] = new Worker("Ronen",8,29,5600);

        int maxYears = 0;
        int maxYearsIndex = 0;

        int maxSalary = 0;
        int maxSalaryIndex = 0;
        for(int i=0;i<workers.length;i++) {

            if(workers[i].getYears() > maxYears) {
                maxYears = workers[i].getYears();
                maxYearsIndex = i;
            }

            if(workers[i].getSalary()  > maxSalary) {
                maxSalary = workers[i].getSalary();
                maxSalaryIndex = i;
            }
        }

        System.out.println("The worker with the highest salary is ");
        workers[maxSalaryIndex].print();

        System.out.println("After adding bonus to the oldest worker");
        workers[maxYearsIndex].addBonus(3000);
        workers[maxYearsIndex].print();


    }
}
