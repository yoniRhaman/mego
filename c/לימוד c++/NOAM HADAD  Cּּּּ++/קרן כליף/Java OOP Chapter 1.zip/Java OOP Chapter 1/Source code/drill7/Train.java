package lesson1.drill7;

/**
 * Created by erankatsav on 29/01/2018.
 */
public class Train {

    private int maxSpeed;
    private String driver;
    private RailroadCar[] cars;
    private int numOfCars;

    private final int MAX_CARS = 10;

    public Train(int maxSpeed, String driver) {
        this.maxSpeed = maxSpeed;
        this.driver = driver;
        cars = new RailroadCar[MAX_CARS];
        numOfCars = 0;
    }

    public int getMaxSpeed() {
        return this.maxSpeed;
    }

    public String getDriver() {
        return this.driver;
    }

    public void setMaxSpeed(int maxSpeed) {
        if(maxSpeed>0)
            this.maxSpeed = maxSpeed;
    }

    public void setDriver(String driver) {
        this.driver = driver;
    }

    public boolean addCar(RailroadCar car) {
        if(this.numOfCars < MAX_CARS) {
            this.cars[numOfCars] = new RailroadCar(car);
            numOfCars++;
            return true;
        }
        return false;
    }

    public boolean addCar(int area, int maxPassengers) {
        return this.addCar(new RailroadCar(area,maxPassengers));
    }

    public int numOfPassengers() {
        int sum = 0;
        for(int i=0;i<numOfCars;i++) {
            sum += cars[i].getCurrentPassengers();
        }
        return sum;
    }

    public RailroadCar maxPassengers() {
        int maxPassengers = 0;
        int maxPassengersIndex = 0;
        for(int i=0;i<numOfCars;i++) {
            if(cars[i].getCurrentPassengers() > maxPassengers) {
                maxPassengers = cars[i].getCurrentPassengers();
                maxPassengersIndex = i;
            }
        }
        return cars[maxPassengersIndex];
    }

    public int addPassengers(int amount) {
        int index = -1;
        for(int i=0;i<numOfCars && index==-1;i++) {
            if(this.cars[i].hasSpace(amount)) {
                this.cars[i].addPassengers(amount);
                index = i;
            }
        }
        if(index!=-1) return (index+1);
        return index;
    }

    public RailroadCar[] freeCars(int amount) {
        int freeCars = 0;
        for(int i=0;i<numOfCars;i++) {
            if(cars[i].hasSpace(amount)) freeCars++;
        }

        RailroadCar[] result = new RailroadCar[freeCars];

        int resultIndex = 0;
        for(int i=0;i<numOfCars;i++) {
            if(cars[i].hasSpace(amount)) {
                result[resultIndex] = new RailroadCar(cars[i]);
                resultIndex++;
            }
        }

        return result;
    }

    public void print() {
        System.out.println("This Train can go up to " + this.maxSpeed + " mph, and the driver is " + this.driver);
        if(numOfCars>0) {
            System.out.println("It has the following cars");
            for(int i=0;i<numOfCars;i++) {
                cars[i].print();
            }
        }
    }
}
