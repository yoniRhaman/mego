package lesson1.drill7;

/**
 * Created by erankatsav on 29/01/2018.
 */
public class TrainMain {

    public static void main(String[] args) {

        RailroadCar car1 = new RailroadCar(20,40,35);
        RailroadCar car2 = new RailroadCar(25,50,40);
        RailroadCar car3 = new RailroadCar(15,30,27);
        RailroadCar car4 = new RailroadCar(25,50,35);
        RailroadCar car5 = new RailroadCar(20,40,0);

        Train train = new Train(100,"Sam");
        train.addCar(car1);
        train.addCar(car2);
        train.addCar(car3);
        train.addCar(car4);
        train.addCar(car5);

        train.print();

        System.out.println("Total number of passengers on the train is " + train.numOfPassengers());

        System.out.println("5 passengers added to car no. " + train.addPassengers(5));
        train.print();
        System.out.println();

        System.out.println("20 passengers added to car no. " + train.addPassengers(20));
        train.print();
        System.out.println();

        System.out.println("10 passengers added to car no. " + train.addPassengers(10));
        train.print();
        System.out.println();

        System.out.println("15 passengers added to car no. " + train.addPassengers(15));
        train.print();
        System.out.println();

        System.out.println("3 passengers added to car no. " + train.addPassengers(3));
        train.print();
        System.out.println();

        System.out.println("20 passengers added to car no. " + train.addPassengers(20));
        train.print();
        System.out.println();

        System.out.println("1 passenger added to car no. " + train.addPassengers(1));
        train.print();
        System.out.println();


        System.out.println("The car with the max passengers is: ");
        train.maxPassengers().print();
    }
}
