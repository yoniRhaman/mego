package lesson1.drill4;

/**
 * Created by erankatsav on 29/01/2018.
 */
public class Fraction {

    private int mone;
    private int mechane;

    public Fraction(int mone, int mechane) {
        this.mone = mone;
        this.mechane = mechane;
    }

    public int getMone() {
        return this.mone;
    }

    public int getMechane() {
        return this.mechane;
    }

    public void setMone(int mone) {
        this.mone = mone;
    }

    public void setMechane(int mechane) {
        if(mechane!=0) {
            this.mechane = mechane;
        }
    }

    public double realValue() {
        return (double)mone/mechane;
    }

    public void add(Fraction other) {

        int oldMechane = this.mechane;
        this.mechane *= other.mechane;
        this.mone = other.mechane*this.mone + oldMechane*other.mone;
    }

    public static Fraction add(Fraction f1, Fraction f2) {
        int newMone, newMechane;
        newMechane = f1.mechane * f2.mechane;
        newMone = f1.mone*f2.mechane + f1.mechane*f2.mone;
        return new Fraction(newMone,newMechane);
    }

    public void simplify() {
        int highestCommonDivider = 1;
        for(int i=this.mone;i>1 && highestCommonDivider==1;i--) {
            if(this.mone % i ==0 && this.mechane % i ==0)
                highestCommonDivider = i;
        }

        this.mone /= highestCommonDivider;
        this.mechane /= highestCommonDivider;
    }

    public void print() {
        System.out.println(this.mone + " / " + this.mechane);
    }

}
