package lesson1.drill4;

/**
 * Created by erankatsav on 29/01/2018.
 */
public class FractionMain {

    public static void main(String[] args) {

        Fraction fraction1 = new Fraction(6,12);
        Fraction fraction2 = new Fraction(5,20);

        System.out.println("Fraction 1 before simplifying:");
        fraction1.print();
        System.out.println("Fraction 2 before simplifying:");
        fraction2.print();

        System.out.println();

        System.out.println("Fraction 1 after simplifying:");
        fraction1.simplify();
        fraction1.print();

        System.out.println("Fraction 2 after simplifying:");
        fraction2.simplify();
        fraction2.print();

        fraction1.add(fraction2);
        fraction1.simplify();
        System.out.println("after adding fraction 2 to fraction 1:");
        fraction1.print();

        Fraction fraction3 = Fraction.add(fraction1,fraction2);
        fraction3.simplify();
        System.out.println("The new fraction is:");
        fraction3.print();


    }
}
