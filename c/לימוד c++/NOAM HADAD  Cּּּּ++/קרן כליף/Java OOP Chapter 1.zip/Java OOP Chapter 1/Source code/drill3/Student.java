package lesson1.drill3;

/**
 * Created by erankatsav on 29/01/2018.
 */
public class Student {

    private String name;
    private String topic;
    private int[] grades;
    private int numOfGrades;

    final int TOTAL_NUM_OF_GRADES = 10;

    public Student(String name, String topic) {
        this.name = name;
        this.topic = topic;
        grades = new int[TOTAL_NUM_OF_GRADES];
        numOfGrades = 0;
    }

    public String getName() {
        return  this.name;
    }

    public String getTopic() {
        return this.topic;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setTopic(String topic) {
        this.topic = topic;
    }

    public boolean addGrade(int grade) {

        if(numOfGrades < TOTAL_NUM_OF_GRADES) {
            grades[numOfGrades] = grade;
            numOfGrades++;
            return true;
        }
        return false;
    }

    public double computeAvg() {
        int sum = 0;
        for(int i=0;i<numOfGrades;i++) {
            sum+=grades[i];
        }
        return (double)sum/numOfGrades;
    }

    public boolean compareAvg(Student other) {
        return this.computeAvg() > other.computeAvg();
    }

    public void print() {
        System.out.println("This is a student his name is " + this.name + " he studies " + this.topic);
        if(numOfGrades>0) {
            System.out.println("His grades are:");
            for(int i=0;i<numOfGrades;i++) {
                System.out.print(grades[i] + ",");
            }
            System.out.println();
        }
    }
}

