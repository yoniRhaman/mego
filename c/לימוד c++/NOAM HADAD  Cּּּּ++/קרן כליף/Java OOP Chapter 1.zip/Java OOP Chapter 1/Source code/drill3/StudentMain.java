package lesson1.drill3;

/**
 * Created by erankatsav on 29/01/2018.
 */
public class StudentMain {

    public static void main(String[] args) {

        Student[] students = new Student[3];

        for(int i=0;i<students.length;i++) {
            students[i] = new Student("moshe " + i,"Biology");
            for(int j=0;j<10;j++) {
                students[i].addGrade((int)(Math.random()*100));
            }
        }

        for(int i=0;i<students.length;i++) {
            students[i].print();
            System.out.println("Student avg is " + students[i].computeAvg());
        }

        double maxStudentAvg = 0;
        int maxStudentAvgIndex = 0;
        for(int i=0;i<students.length;i++) {

            if(students[i].computeAvg() > maxStudentAvg) {
                maxStudentAvg = students[i].computeAvg();
                maxStudentAvgIndex = i;
            }
        }

        System.out.println("the student with the max average is: ");
        students[maxStudentAvgIndex].print();
    }
}
