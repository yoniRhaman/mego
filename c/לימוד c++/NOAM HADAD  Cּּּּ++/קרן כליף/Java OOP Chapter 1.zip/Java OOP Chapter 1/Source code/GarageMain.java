package lesson1;

/**
 * Created by erankatsav on 28/01/2018.
 */
public class GarageMain {

    public static void main(String[] args) {

        Garage habira = new Garage("Habira","Jerusalem");

        habira.print();

        habira.addCar(new Car(80000, "Yellow"));
        habira.addCar(new Car(6000, "Red"));
        habira.addCar(new Car(100000, "Black"));
        habira.addCar(new Car(50000, "Green"));
        habira.addCar(new Car(40000, "White"));

        System.out.println("Habira after adding a few cars");
        habira.print();
    }
}
