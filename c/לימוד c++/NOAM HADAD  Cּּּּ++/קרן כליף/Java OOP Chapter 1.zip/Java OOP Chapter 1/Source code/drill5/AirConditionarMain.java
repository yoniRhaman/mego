package lesson1.drill5;

/**
 * Created by erankatsav on 29/01/2018.
 */
public class AirConditionarMain {

    public static void main(String[] args) {

        AirCondtionar yoav,dad,mom;
        yoav = dad = mom = new AirCondtionar();

        dad.onOff();
        dad.setTemp(22);

        System.out.println("Yoav:");
        yoav.print();

        yoav.setTemp(26);
        System.out.println("Mom:");
        mom.print();

        mom.onOff();

        System.out.println("Dad:");
        dad.print();




    }
}
