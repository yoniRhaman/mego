package lesson1.drill5;

/**
 * Created by erankatsav on 29/01/2018.
 */
public class AirCondtionar {

    private String manufacture;
    private int temp;
    private boolean isOn;


    public void setTemp(int temp) {
        if(temp>= 16 && temp<=32) {
            this.temp = temp;
        }
    }

    public void onOff() {
        this.isOn = !this.isOn;
    }

    public void tempUp() {
        if(this.temp < 32) {
            this.temp++;
        }
    }

    public void tempDown() {
        if(this.temp > 16) {
            this.temp--;
        }
    }

    public void print() {
        System.out.println("The air conditioner manufactured by " + this.manufacture + " and it is " + (isOn ? "on" : "off"));
        if(isOn)
            System.out.println("it's temperature is " + this.temp);
    }
}
